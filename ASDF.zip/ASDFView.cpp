﻿
// ASDFView.cpp: CASDFView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "ASDF.h"
#endif

#include "ASDFDoc.h"
#include "ASDFView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#include <vector>


// CASDFView

IMPLEMENT_DYNCREATE(CASDFView, CFormView)

BEGIN_MESSAGE_MAP(CASDFView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CASDFView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN1, &CASDFView::OnDeltaposSpin1)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CASDFView::OnCbnSelchangeCombo1)
	ON_WM_MOUSEMOVE()  // 여기를 추가합니다.
	ON_WM_LBUTTONDOWN()  // 여기를 추가합니다.
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_CHECK1, &CASDFView::OnBnClickedCheck1)
END_MESSAGE_MAP()

// CASDFView 생성/소멸

CASDFView::CASDFView() noexcept
	: CFormView(IDD_ASDF_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CASDFView::~CASDFView()
{
}

void CASDFView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Edit);
	DDX_Control(pDX, IDC_SPIN1, m_Spin);
	DDX_Control(pDX, IDC_COMBO1, m_Cmb);
	DDX_Control(pDX, IDC_CHECK1, m_Check);
}

BOOL CASDFView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CFormView::PreCreateWindow(cs);
}

void CASDFView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}


// CASDFView 인쇄


void CASDFView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CASDFView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CASDFView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CASDFView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CASDFView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}

void CASDFView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CASDFView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CASDFView 진단

#ifdef _DEBUG
void CASDFView::AssertValid() const
{
	CFormView::AssertValid();
}

void CASDFView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CASDFDoc* CASDFView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CASDFDoc)));
	return (CASDFDoc*)m_pDocument;
}
#endif //_DEBUG





CPoint oPnt;
struct Line {      //구조체 형성
	CPoint start;
	CPoint end;
	int penWidth;
	COLORREF color;
};

std::vector<Line> lines; //벡터를 사용한 선 추가

void CASDFView::OnLButtonDown(UINT nFlags, CPoint point)
{
	oPnt = point;
	CFormView::OnLButtonDown(nFlags, point);
}

void CASDFView::OnMouseMove(UINT nFlags, CPoint point)
{
	if (nFlags & MK_LBUTTON) { // 마우스 왼쪽 버튼의 상태만 확인
		CClientDC dc(this); // 여기서 DC를 얻어옵니다.
		//펜 굵기 가져오기
		CString PenW;
		m_Edit.GetWindowTextW(PenW);
		int penW = _ttoi(PenW);

		COLORREF color;

		if (m_Check.GetCheck() == BST_CHECKED) {
			// If the checkbox is checked, use the eraser.
			color = RGB(255, 255, 255);  // Assuming your background is white
		}
		else {
			int SelectedColor = m_Cmb.GetCurSel();
			CString PenC;

			if (SelectedColor != CB_ERR)
				m_Cmb.GetLBText(SelectedColor, PenC);
			else
				PenC = _T("Black");  // Default to black if no color is selected

			if (PenC.CompareNoCase(_T("Red")) == 0)
				color = RGB(255, 0, 0);
			else if (PenC.CompareNoCase(_T("Green")) == 0)
				color = RGB(0, 255, 0);
			else if (PenC.CompareNoCase(_T("Blue")) == 0)
				color = RGB(0, 0, 255);
			else
				color = RGB(0, 0, 0);     // 기본값은 검은색 
		}

		CPen pen(PS_SOLID, penW, color);
		CPen* poldPen = dc.SelectObject(&pen);

		dc.MoveTo(oPnt);
		dc.LineTo(point);

		lines.push_back({ oPnt , point , penW ,color });
		oPnt = point;      // 현재 위치 저장

		Invalidate();   // Add this line to invalidate the window

		UpdateData();
	}
}

void CASDFView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	for (const auto& line : lines) {
		CPen pen(PS_SOLID, line.penWidth, line.color);
		CPen* poldPen = dc.SelectObject(&pen);

		dc.MoveTo(line.start);
		dc.LineTo(line.end);

		dc.SelectObject(poldPen);
	}
}

void CASDFView::OnDeltaposSpin1(NMHDR* pNMHDR, LRESULT* pResult) {
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);

	CString str;
	str.Format(_T("%d"), pNMUpDown->iPos + pNMUpDown->iDelta);
	m_Edit.SetWindowTextW(str);

	m_Spin.SetRange(1, 100);

	UpdateData(FALSE);

	Invalidate();
	UpdateWindow();

}


void CASDFView::OnCbnSelchangeCombo1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}


void CASDFView::OnBnClickedCheck1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}
